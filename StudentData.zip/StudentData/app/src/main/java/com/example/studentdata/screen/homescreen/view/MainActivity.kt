package com.example.studentdata.screen.homescreen.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.studentdata.databinding.ActivityMainBinding
import com.example.studentdata.screen.homescreen.controller.HomeAdapter
import com.example.studentdata.screen.homescreen.model.ModelData
import com.example.studentdata.utils.Dbhelper

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    var list = arrayListOf<ModelData>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var db = Dbhelper(this)




//        for(i in 0 until list.size)
//        {
//            Log.e("TAG", "onCreate: ===>"+ list.get(i).id + "     "+list.get(i).name)
//        }


        binding.insertBtn.setOnClickListener {
            db.insertData(binding.nameEdt.text.toString(),
                            binding.classEdt.text.toString(),
                            binding.StdEdt.text.toString(),
                            binding.attendence.text.toString(),
                            binding.Leaves.text.toString())


        }

        binding.readBtn.setOnClickListener {

            list = db.readData()

            setUpRv(list)
        }
    }

    fun setUpRv(list: ArrayList<ModelData>) {

        var adapter = HomeAdapter(this,list)
        var lm = LinearLayoutManager(this)
        binding.view.layoutManager = lm
        binding.view.adapter = adapter

    }
}



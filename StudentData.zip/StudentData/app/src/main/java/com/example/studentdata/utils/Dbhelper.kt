package com.example.studentdata.utils

import android.annotation.SuppressLint
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.core.content.contentValuesOf
import com.example.studentdata.screen.homescreen.model.ModelData

data class Dbhelper(val context: Context?) : SQLiteOpenHelper(context, "AlldataDb.db",null,1) {
    override fun onCreate(db: SQLiteDatabase?) {
        var query = "CREATE TABLE studentTb (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,class1 TEXT,std TEXT,attendence TEXT,leave TEXT)";
        db?.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {

    }

    fun insertData(n1:String,c1:String,s1:String,a1:String,l1:String)
    {

        var db = writableDatabase

        var cv = contentValuesOf()
        cv.put("name",n1)
        cv.put("class1",c1)
        cv.put("std",s1)
        cv.put("attendence",a1)
        cv.put("leave",l1)

        var res = db.insert("studentTb",null,cv)
        println(res)
    }

    @SuppressLint("Range")
    fun readData(): ArrayList<ModelData> {
        var list = arrayListOf<ModelData>()

        var db = readableDatabase

var s="test"
        var query = "SELECT *FROM studentTb "

        var cursor = db.rawQuery(query,null)

        if(cursor.moveToFirst() && cursor.count > 0)
        {
            do{
                var id = cursor.getString(cursor.getColumnIndex("id"))
                var name = cursor.getString(cursor.getColumnIndex("name"))
                var class1 = cursor.getString(cursor.getColumnIndex("class1"))
                var std = cursor.getString(cursor.getColumnIndex("std"))
                var attendence = cursor.getString(cursor.getColumnIndex("attendence"))
                var leave = cursor.getString(cursor.getColumnIndex("leave"))

                var m1 = ModelData(id,name,class1,std,attendence,leave)
                list.add(m1)

            }while (cursor.moveToNext())
        }

        return list
    }

}

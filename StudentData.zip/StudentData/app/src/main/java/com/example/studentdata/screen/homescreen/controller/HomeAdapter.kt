package com.example.studentdata.screen.homescreen.controller

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.studentdata.R
import com.example.studentdata.screen.homescreen.model.ModelData
import com.example.studentdata.screen.homescreen.view.MainActivity

data class HomeAdapter(val mainActivity: MainActivity, val list: ArrayList<ModelData>) : RecyclerView.Adapter<HomeAdapter.viewData>()
{
    class viewData(itemView : View) : RecyclerView.ViewHolder(itemView)
    {
        var id_txt = itemView.findViewById<TextView>(R.id.id_txt)
        var name_txt = itemView.findViewById<TextView>(R.id.name_txt)
        var class_txt = itemView.findViewById<TextView>(R.id.class_txt)
        var std_txt = itemView.findViewById<TextView>(R.id.std_txt)
        var attendence_txt = itemView.findViewById<TextView>(R.id.attendence_txt)
        var leave_txt = itemView.findViewById<TextView>(R.id.leave_txt)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewData {
        var view  = LayoutInflater.from(mainActivity).inflate(R.layout.item,parent,false)
        return viewData(view)
    }

    override fun onBindViewHolder(holder: viewData, position: Int) {

        holder.id_txt.text = list[position].id
        holder.name_txt.text = list[position].name
        holder.class_txt.text = list[position].class1
        holder.std_txt.text = list[position].std
        holder.attendence_txt.text = list[position].attendence
        holder.leave_txt.text = list[position].leave



    }

    override fun getItemCount(): Int {
        return list.size

    }

}

package com.example.studentdata.screen.homescreen.model

class ModelData(
    val id: String,
    val name: String,
    val class1: String,
    val std: String,
    val attendence: String,
    val leave: String
) {

}
